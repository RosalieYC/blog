-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 12, 2018 at 10:56 AM
-- Server version: 10.1.36-MariaDB
-- PHP Version: 7.2.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `blogs`
--

-- --------------------------------------------------------

--
-- Table structure for table `bloggers`
--



CREATE TABLE `bloggers` (
                          `id` int(10) UNSIGNED NOT NULL,
                          `name` varchar(255) COLLATE utf8mb4_bin NOT NULL,
                          `birth_date` date NOT NULL,
                          `address` varchar(255) COLLATE utf8mb4_bin NOT NULL,
                          `bio` varchar(255) COLLATE utf8mb4_bin NOT NULL,
                          `username` varchar(255) COLLATE utf8mb4_bin NOT NULL,
                          `password` varchar(255) COLLATE utf8mb4_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

--
-- Dumping data for table `bloggers`
--

INSERT INTO `bloggers` (`id`, `name`, `birth_date`, `address`, `bio`, `username`, `password`) VALUES
(1, 'Andrew Zaleski', '1980-06-10', 'Washington', 'Mostly I write about technology, science, and business. And I write profiles on people who do, and don\'t do, work in those fields.', 'Andrew', '198006'),
(2, 'Robert Horvat', '1993-11-30', 'Melbourne', 'He believes that the world is round and that art is one of our most important treasures. He has seen far too many classic films and believes coffee runs through his veins. As a student of history, he favours ancient and medieval history.', 'Robert', '199311'),
(3, 'Robbie Gonzalez', '1987-03-01', 'San Francisco', 'Senior Writer at WIRED', 'Robbie', '198603'),
(4, 'Matthew Kepness', '1981-06-12', 'Boston', 'Hi, Iâ€™m Nomadic Matt, a New York Times best-selling author of How to Travel the World on $50 a Day ', 'Matthew', '198106');

-- --------------------------------------------------------

--
-- Table structure for table `blogs`
--

CREATE TABLE `blogs` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `blogger_id` int(10) NOT NULL,
  `category_id` int(10) NOT NULL,
  `date` date NOT NULL,
  `image` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  `text` mediumtext COLLATE utf8mb4_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

--
-- Dumping data for table `blogs`
--

INSERT INTO `blogs` (`id`, `title`, `blogger_id`, `category_id`, `date`, `image`, `text`) VALUES
(1, '10 Best places to travel on a budget', 4, 2, '2018-10-30', 'https://kag417.files.wordpress.com/2013/07/20130722_003211-kdcol', 'The world is full of affordable destinations, and it doesnâ€™t require much effort to find them. No matter what continent, there are always places you can visit on a budget â€” even countries we think of as expensive are quite budget-friendly if you know certain tips and tricks. No destination is really ever â€œtoo expensive.â€ After 10 years as a frugal budget traveler and, in light of the release of my new book, today I want to talk about my favorite budget travel destinations from the last 10 years. These destinations are my favorite countries and regions for getting the most value for your money, meeting friendly locals and travelers, eating well, and having fun.\r\n\r\nIf youâ€™re looking to travel on a low budget and wondering where you should go, here are the 10 best and cheapest places to travel internationally:\r\n\r\n1. Fiji\r\nlaying in a hammock in fiji\r\nMost of us imagine Pacific Island destinations as expensive destinations filled with high priced resorts, food, and services. However, thatâ€™s not always the case. Fiji, unlike its expensive island neighbors and sharp marketing by Fiji water, is actually relatively cheap to visit. While there are many $1,000-a-night resorts in the country, you can manage to enjoy pristine beaches, world-class diving, tasty seafood, and friendly locals without having to mortgage your home.\r\n\r\nSince Fiji is a stopover on Fiji Airlines, youâ€™ll find a lot of flight deals to the country. Many backpackers take advantage of that and a small backpacker community has emerged. That means cheap guesthouses, transportation, and activities, especially in the popular Yasawa Islands. Even if youâ€™re not a backpacker, you can take advantage of all these deals and save money. Fiji is one of the best budget destinations on the region and not to be missed.\r\n\r\n2. Central America\r\nthe jungles of central america in costa rica\r\nWant to roam ancient ruins, trek through the jungle, surf, and eat delicious food with few tourists around? Visit the smaller countries in Central America â€” think El Salvador, Honduras, Nicaragua, and Guatemala. Here you will find most budget hotels for around $15 per night, meals for $3, most bus journeys for the same price, and beer for less than a dollar.\r\n\r\nBeliza, Panama, Costa Rica â€“ these are expensive destinations by regional standards. If you visit the central Central American countries, you can get by on $40 a day as a backpacker or splash up to $60 a day and live large. Your money goes really far in this part of the world.\r\n\r\n3. Cambodia\r\na monk at Angkor Wat Cambodia\r\nWhile you could put all of Southeast Asia on the list, Cambodia is one of my favorite countries in the region â€” itâ€™s affordable, beautiful, and the locals are incredibly hospitable. You can get a private, air-conditioned room for $20 USD, street food for $2, and transportation across the country for $20. If you are spending close to $50 a day, you are living large. Itâ€™s way cheaper than all its neighbors, just as beautiful, and filled with some of the nicest people in the world. Itâ€™s one of the cheapest backpacking destinations in the world!\r\n\r\n4. China\r\nshanghai china at night\r\nChina has fascinated travelers ever since Marco Polo traversed the Silk Road. While the days of China being a super-cheap destination are long gone, the country remains a budget destination â€“ and one of the cheapest in Asia â€“ but with a caveat. You need to get out of the big cities. Sure, the cities are still a bargain. Hostels cost less than $20 a day, food is $2-5 per meal, and local transportation in cities runs less than a dollar. But, the country becomes even cheaper, when you get off the beaten path and the interior. This is where youâ€™ll find the best travel deals and bargains! China still remains one of the best value places in the world.\r\n\r\n5. South Korea\r\nchanging of the guard at the palace in south korea\r\nSouth Korea is a country not talked about enough. To me, South Korea is one of the greatest â€œundiscoveredâ€ travel destinations in the world â€” its prices rival that of Southeast Asia, itâ€™s high tech, the food is mind blowing delicious and eclectic, the countryside is jaw-dropping beautiful, and the nightlife is out of this world. It is one of the most underrated travel destinations out there. With the South Korean currency at 1,100 won per $1 USD and most everything costing only a few thousand won, itâ€™s hard to bust your budget here. My friend and I went out for Korean BBQ complete with drinks, and we each spent $8. You can pick up bottles of beer in 7-Eleven for less than a dollar. Trains are cheap. Everything here is cheap â€“ plus itâ€™s fun and different! If youâ€™re looking for a budget trip to Asia, visit South Korea. There are lots of international flights to here!\r\n\r\n6. India\r\nthe country side in india\r\nWhile always a cheap country, the Indian rupee used to ride high at 39 rupees to the US dollar. Now, you get 73 rupees to the dollar â€” thatâ€™s nearly 50 percent more money to travel with. Unless you book five-star resorts and eat only Western meals, youâ€™ll find it hard to spend $50 a day here. You can get by on closer to $30 by staying in cheap guest houses, taking second-class trains, and avoiding Western food. India a cheap backpacking destination â€“ heck, just a cheap travel destination â€“ with a rich cultural history, top class food, helpful and curious locals, incredible regional diversity, great tea, and a lot to do. Itâ€™s a gigantic place best either explored in either one large trip or a few smaller chunks. Either way, donâ€™t miss India.\r\n\r\n7. Eastern Europe\r\na little town near velinko tarnovo, bulgaria\r\nFar Eastern Europe (Ukraine, Bulgaria, Romania, Moldova) is the cheapest part of the continent. Itâ€™s a sin most people donâ€™t visit this region more. I was living like a king for less than $40 per day, paying $8 a night for a room in Ukraine, $1.50 for a liter of beer in Bulgaria, and a few dollars for transportation. Eastern Europe has the charm and beauty of the West without the high prices or hordes of tourists youâ€™ll find in Paris, Prague, or Barcelona. They are not the impoverished ex-Communist countries most people still think them to be. If youâ€™re looking for something a little more off the beaten path, come to this area of the world.\r\n\r\n8. Portugal\r\nthe cityscape of lisbon, portugal\r\nNot all Euro countries are created equal, and Portugal is one of the bargain countries in the region â€” and one of my favorites. I fell in love with the country the first time I visited â€” how could I not, with beautiful beaches, wine country, stunning cliffs, delicious food, jovial locals, and historic cities all at bargain prices. Portugal has become a lot more popular and crowded in recent years. Lisbon has become especially expensive was people move there and drive up prices. Itâ€™s a great place after all! However, once you get outside of Lisbon, prices are still relatively cheap compared, even if the crowds are a bit larger these days!\r\n\r\n9. Australia\r\nthe australian outback\r\nWhile an unlikely candidate to be listed on a â€œcheap destinationsâ€ list because itâ€™s known to be incredibly expensive, Australia can also be incredibly cheap â€“ if you know a few tricks! Thanks to a lot of work exchange opportunities, a well-worn budget backpacker trail, lots of Couchsurfing hosts, and cheap groceries, you can visit Australia on a budget. Additionally, Australia has become cheaper thanks to the 20% drop in the Australian dollar has tempered that price increase and made Australia the most affordable it has been in years.\r\n\r\nFor more information, check out this detailed planning guide on Australia.\r\n\r\n10. Thailand\r\nko tarato national park in souther thailand\r\nOn every list ever about budget travel, Thailand is where it all began for me so it holds a special place in my heart. It is where I decided to quit my job and travel the world. I lived there. I loved there. Thailand is incredible. With a tourist trail going back decades, Thailand is the heart of backpacking in Southeast Asia, and you can get by on between $25-30 a day thanks to cheap guesthouses, street food, local buses, and attractions. If you spend all your time on the islands and in expensive accommodation, expect to pay closer to $50 USD a day. However, even at the price, Thailand is still one of the most bargain destinations in the world and should not be skipped!\r\n\r\n******\r\nI believe most destinations in the world can be explored on a budget without sacrificing too much comfort (heck, I even traveled Iceland on $50 a day). If youâ€™re a savvy traveler, you know how to maximize your money no matter where you go in the world. But your mission to find the cheapest places to travel in the world is a lot easier when the places youâ€™re going to are already affordable.\r\nSo visit one of these spots and save! '),
(2, 'The science of growing a perfect Christmas Tree', 3, 3, '2018-10-18', 'https://www.profitableplantsdigest.com/wp-content/uploads/2012/0', 'EVERY WINTER, MILLIONS of Americans descend on farms and lots across the country with the express purpose of inspecting, and ultimately choosing from, their local selection of coniferous evergreen trees. I\'m talking, of course, about Christmas tree shoppingâ€”the widely practiced pastime of publicly scrutinizing spruces, pines, and firs in search of the ideal yuletide centerpiece.\r\n\r\nMany people are practiced at picking the perfect tree. They\'ll judge on things like color, size, shape, needle quality, and bushiness. But behind the annual selection of a coniferous house guestâ€”some 30 million of them a year, in the USâ€”is a ton of science.\r\n\r\nTo Bert Cregg, identifying exactly what makes a tree perfect is more than a holiday tradition, it\'s a major part of his job. He\'s a forest researcher at Michigan State University and a renowned expert on Christmas tree production. His work covers two main areas: genetics and culture techniques. \"Basically, how can we identify species and seed sources that are going to lead to better Christmas trees, and how can growers manage their farms to produce better trees,\" he says.\r\n\r\nThe research Cregg and his colleagues are conducting today will likely influence what type of Christmas tree you buy from your local lot a decade from now.\r\n\r\nConsider Cregg\'s cold-hardiness experiments, one of which he\'s currently performing inside a chest freezer in the basement of MSU\'s Plant and Soil Sciences Building. \"We collect a bunch of shoots from the trees we want to study, stick them in the freezer, and program it to decrease 3 degrees Celsius every hour,\" Cregg says. Every 60 minutes, he and his team retrieve some shootsâ€”at minus 3, minus 6, minus 9, minus 12â€”until the freezer reaches minus 45 degrees Celsius, which is as cold as it goes. Then they incubate the samples.\r\n\r\n\r\nA week later, they inspect the shoots to see which ones have begun to brownâ€”a sign of damageâ€”and at what temperature. The thinking goes that the colder a given species of tree can get before browning, the more resilient it will be in frigid climates. And the more resilient a tree is, the more likely it is to endure multiple winters and still come out looking living-room ready. \"So, if we\'re thinking of selecting a new species or seed source, we can screen [that species] rapidly, rather than waiting for that 1-in-20 winter to determine if a tree is hardy enough for a given location,\" Cregg says.\r\n\r\nHardiness is but one of many coniferous characteristics Cregg studies in pursuit of increasingly perfect Christmas trees. Thereâ€™s also size and color, for starters. Farmers see to both by fertilizing often; regular mulches keep trees verdant and growing at a rate of roughly one foot per year. But historically, growers overdid it. Old guidelines prescribed around 300 pounds of nitrogen fertilizer per acreâ€”way more than the trees needed. Microbes in the soil would convert the excess nitrogen into nitrate, which would work its way past the tree\'s roots, deep into the soil, and infiltrate the ground water. Cregg\'s lab showed that farmers could reduce their fertilizer requirements by two-thirds if they applied it on a per-tree basis, according to the size, species, and age of their trees. The result was greener trees, less nitrogen runoff, and more money in farmers\' pockets.\r\n\r\nThere\'s also things like needle retentionâ€”literally, how many needles stay stuck to the branch, and how many rain down on the presents underneath? Cregg and his colleagues assess this by plucking sprigs from a variety of fir species and displaying them in rows at a horticultural farm on campus. Once a week, a researcher will swing through, give each sprig a gentle tug along its length, and tally how many needles fall off. \"We simply go through, give a pull, and we have a rating scale based on how many needles drop,\" Cregg says. \"We can display a Fraser fir for six weeks, and it won\'t drop any needles. Noble fir, same thing. And that\'s one reason people in the Northwest like noble firs.\"\r\n\r\nAnd then there are issues like coning, and how to deal with it. Coning as in pinecones, which, in this context, are a bad thing. \"Anybody on the outside looking in would probably say: Why\'s that an issue?\" Cregg says. \"I get it. It\'s a little out there. But cones are probably the single biggest problem our growers face here in the Midwest.\"\r\n\r\nTake Fraser firs, for example. It\'s the tree of choice for farmers in Michigan and North Carolina, the country\'s third- and second-biggest growers of Christmas trees, respectively, behind Oregon. In nature, most firs don\'t produce cones until they\'re 15 years old, but on farmsâ€”most of which harvest trees no later than their tenth seasonâ€”they\'ll appear after only a few years. They bud in the spring and develop through the summer, robbing the trees of resources. (From an evolutionary perspective, reproduction comes first, so the trees sink their energy into producing cones.) But the cones don\'t stick around. Come fall they disintegrate, showering the tree in unsightly fragments.\r\n\r\n\r\nSo in the springtime, growers pick the cones. By hand. It\'s not difficult, exactly; if you time it right, a bud the size of your little finger will pop right off, with a twist. But it takes forever: An individual tree can carry hundreds of cones. On a big one you might pluck a thousand. With millions of firs growing across the US, and most of them experiencing some kind of coning, we\'re talking about billions of cones.\r\n\r\nCregg thinks plant growth regulators, which nerf the cone-promoting hormone in firs, could help curb the problem. For the past few years, he\'s been working to identify the ideal regulator, and how best to apply it. His latest approach isn\'t perfect, he says, but it can reduce coning by about half. It also has the desirable side effect of keeping trees nice and dense. The main hangup: Applying growth regulators doesn\'t yet make financial sense. \"Biologically it works, but it\'s not quite to the point of being cost effective,\" Cregg says.\r\n\r\nPerhaps the most ambitious Christmas tree science happening today is a multi-institutional endeavor called CoFirGE. Short for Collaborative Fir Germplasm Evaluation Project, CoFirGE is a nationwide effort whose goals include identifying new species of fir for Christmas trees. There are between 30 and 40 species of firs worldwide, a small handful of which are currently grown for the North American Christmas tree market. Two of today\'s most popular treesâ€”the Fraser and noble firâ€”both struggle with a condition called root rot. Caused by the water-mold genus Phytophthora, a tree stricken with it can die in a matter of days. It\'s currently a huge problem in America\'s biggest tree-growing states, but in Turkey, fir trees are resistant to root rot. So today, through the CoFirGE project, there are species of Turkish fir growing in Michigan, Pennsylvania, Connecticut, North Carolina, Washington, and Oregon, to see how adaptable they are to US climates.\r\n\r\nAll things to keep in mind, the next time you find yourself wandering the rows of evergreens at your local lot. Remember: Long before you arrived to judge the local stock on things like color, shape, and freshness, scientists like Cregg were stashing firs in freezers and pulling at pine needles, all in pursuit of a more perfect Christmas tree.'),
  (3, 'What gives a sunset its color?', 1, 3, '2018-12-11', 'https://upload.wikimedia.org/wikipedia/commons/5/58/Sunset_2007-', 'Next time you\'re watching a sunset on the beach, think about the amazing physics that\'s bringing you the view.\r\n \r\nGaze up at the sky one evening and youâ€™re likely to see the crisp blue sky of the afternoon replaced with a reddish-orange hue stretching for miles. You might be wondering: Why does the color of the sky change at different times of the day? The answer has to do with how light from the Sun interacts with the atmosphere surrounding the Earth.\r\n\r\nLight travels in waves. Every color we see is determined by the length of those waves. Red wavelengths are the longest, and as you go through the rainbow the waves get shorter and shorter until you reach the blues and violets, which are the smallest.\r\n\r\nAs the Sunâ€™s light travels towards us, at first all it encounters is the emptiness of space. But here on Earth, swirling in the air around us are thousands of near-invisible particles. Dust and water droplets are the larger ones, but there are also the minuscule gas moleculesâ€”mostly oxygen and nitrogenâ€”that make up the air itself. The wavelengths that make it to the Earthâ€™s atmosphere collide with these particles, which sends light bouncing in many different directions. Think of it like this: If youâ€™ve ever been in a crowded bumper-car pavilion at an amusement park, bumping into other cars and being bumped into yourself, youâ€™ve played the part of a light wave.\r\n\r\nBut not all wavelengths bounce around to the same degree.\r\n\r\nâ€œThe atmosphere acts as a filter, and itâ€™s always happening, you just donâ€™t necessarily know it. Itâ€™s basically an effect of selective scattering,â€ says Stephen Corfidi, a meteorologist at the National Oceanic and Atmospheric Administration.\r\n\r\nBlue wavelengths, because of their smaller size, are scattered more easily and in many directions. Red wavelengths, which are larger, are scattered the least by those tiny particles in the air.\r\n\r\nDuring the day, when the light has the shortest distance to travel through the atmosphere, what we end up seeing are the blue waves that have been scattered all across the sky. At the dayâ€™s end, though, the light has to travel through much more of the atmosphere, and those short, blue light waves have a tough time getting past all the molecules. They mostly get scattered away before they ever reach us. The result is that red sky we see at sunset, since longer red wavelengths are still able to penetrate the atmosphere.\r\n\r\n\r\nSo when you see a red sky at night, just remember that itâ€™s actually the last remaining survivor of the whole rainbow of colors.'),
 (4, 'Behind the legend of Santa Claus exists a humble saint.', 2, 1, '2018-12-10', 'https://upload.wikimedia.org/wikipedia/commons/6/62/Nikola_from_', 'Does St. Nicholas deserve his place amongst humanities most kindest, gentlest, generous and loving individuals to have walked this earth? Maybe, probably, yeah why not! It is astonishing to think that from humble beginnings, he was a man who put everyone ahead of himself, especially the poor and needy, the innocent and those who staved from famine. He also had the reputation of gift-giving, such as, in the stories told of him providing dowries of gold to poor girls or leaving coins in the shoes of those who left them out for him. He has inspired billions of Christians around the world today, as the popular figure or folk legend of Santa Claus or Father Christmas. It is important to note that over time his legend has been combined with elements of the Norse god Odin and Nordic tales of magicians who rewarded good children with gifts and punished naughty children with none.\r\n\r\nThe historic Saint Nicholas was a fourth century priest, the Bishop of Myra in Lycia (Anatolia or modern-day Turkey). He was born (270 AD) during a turbulent time in history when the persecution of Christians was still a common practice. After his parents died, he was taken in by his uncle, who was a bishop himself. He raised and trained Nicholas as a church reader and later ordained him as a priest. Legend states when he came to Myra, the clergy of Myra and the people of the region, who were in the middle of electing a new bishop, without hesitation chose Nicholas as the man indicated by God to be their next bishop. However, before he could settle down in his position as bishop, the Roman magistrates in his province, arrested and tortured Nicholas, and eventually chained and threw him into prison. Not until Constantine the Great proclaimed the Edict of Milan in 312 AD, granting Christians religious liberty, would Nicholas and all other Christian prisoners be released.\r\n\r\nSt. Nicholas would return to his post as Bishop of Myra and later even answer to the request of Constantine to appear at the First Council of Nicaea in 325 AD. At the council, he apparently rejected the teachings of Arianism. St. Methodius is allegedly quoted as saying that â€œthanks to the teaching of St. Nicholas the (province) of Myra alone was untouched by the filth of the Arian heresy, which it firmly rejected as death-dealing poison.â€ St. Nicholas would also as one of the many bishops at the council, sign the Nicene Creed as a defender of the Orthodox faith.\r\n\r\nMuch of his life and work as a generous and kind man and subsequent miracles are steeped in legend. Stories of his good deeds are many and are commemorated in icons throughout the ages. He is revered by both the Catholic and Orthodox churches as a saint. Though, it seems that his greatest popularity lies in Russia. He is also famously the patron saint of children, which undoubtedly gives rise to his popularity as the â€œoriginal Santa Clausâ€. Importantly, he is also patron saint of Greece, sailors, merchants, the falsely accused, pawnbrokers and the Varangian Guard of the Byzantine emperors.');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
                            `id` int(10) NOT NULL,
                            `name` varchar(255) COLLATE utf8mb4_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`) VALUES
(1, 'history'),
(2, 'travel'),
(3, 'science');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bloggers`
--
ALTER TABLE `bloggers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `blogs`
--
ALTER TABLE `blogs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `bloggers`
--
ALTER TABLE `bloggers`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `blogs`
--
ALTER TABLE `blogs`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
