<?php

declare(strict_types=1);

use App\Controller\AdminController;
use App\Controller\BlogController;
use App\Controller\BloggerController;
use App\Controller\CategoryController;
use Dotenv\Dotenv;

require_once (__DIR__. '/../vendor/autoload.php');

$dotenv = new Dotenv(__DIR__ .'/../');
$dotenv->load();

$route = $_GET['route'] ?? 'blog-overview';
$method = $_SERVER['REQUEST_METHOD'];

if ($route == 'blog-overview') {
    $blogController = new BlogController();
    $blogController->showBlogs();
} else if ($route == 'blogger') {
    $bloggerController = new BloggerController();
    $bloggerController->showBlogger();
} else if ($route == 'blog') {
    $blogId = (int)$_GET['id'];
    $blogController = new BlogController();
    $blogController->showBlog($blogId);
} else if ($route == 'category') {
    $categoryController = new CategoryController();
    $categoryController->showCategory();
} else if ($route == 'admin-overview') {
    $adminController = new AdminController();
    $adminController->adminOverview();
} else if ($route == 'admin-blog') {
    $adminController = new AdminController();
    $adminController->adminBlogs();
} else if ($route == 'admin-blogger') {
    $adminController = new AdminController();
    $adminController->adminBloggers();
} else if ($route == 'admin-category') {
    $adminController = new AdminController();
    $adminController->adminCategories();
} else if ($route == 'addblog' && $method == 'GET') {
    $blogController = new BlogController();
    $blogController->newBlog();
} else if ($route == 'addblog'  && $method == 'POST') {
    $bookFields = $_POST;
    $blogController = new BlogController();
    $blogController->addBlog($bookFields);
} else if ($route == 'editblog' && $method == 'GET'){
    $blogId = (int)$_GET['id'];
    $blogController = new BlogController();
    $blogController->showEditBlog($blogId);
} else if ($route == 'editblog' && $method == 'POST'){
    $blogId = (int)$_GET['id'];
    $blogFields = $_POST;
    $blogController = new BlogController();
    $blogController->updateBlog($blogId, $blogFields);
} else if ($route == 'deleteblog' && $method == 'POST'){
    $blogId = (int)$_GET['id'];
    $blogController = new BlogController();
    $blogController->deleteBlog($blogId);
} else if ($route == 'addblogger' && $method == 'GET') {
    $bloggerController = new BloggerController();
    $bloggerController->newBlogger();
} else if ($route == 'addblogger'  && $method == 'POST') {
    $bloggerFields = $_POST;
    $bloggerController = new BloggerController();
    $bloggerController->addBlogger($bloggerFields);
} else if ($route == 'editblogger' && $method == 'GET'){
    $bloggerId = (int)$_GET['id'];
    $bloggerController = new BloggerController();
    $bloggerController->showEditBlogger($bloggerId);
} else if ($route == 'editblogger' && $method == 'POST'){
    $bloggerId = (int)$_GET['id'];
    $bloggerFields = $_POST;
    $bloggerController = new BloggerController();
    $bloggerController->updateBlogger($bloggerId, $bloggerFields);
} else if ($route == 'deleteblogger' && $method == 'POST'){
    $bloggerId = (int)$_GET['id'];
    $bloggerController = new BloggerController();
    $bloggerController->deleteBlogger($bloggerId);
} else if ($route == 'addcategory' && $method == 'GET') {
    $categoryController = new CategoryController();
    $categoryController->newCategory();
} else if ($route == 'addcategory'  && $method == 'POST') {
    $categoryFields = $_POST;
    $categoryController = new CategoryController();
    $categoryController->addCategory($categoryFields);
}