# Team opdracht: Blog

Welkom bij jullie team opdracht! De titel heeft het wellicht al een beetje verraden, we gaan een blog platform maken! :-)

Lees verder om te begrijpen waar het blog inhoudelijk en technisch aan moet voldoen, en hoe je je werkproces kunt inrichten om dit project te gaan realiseren.

## Inleiding

Het blog platform biedt meerdere bloggers de mogelijkheid om een blog aan te maken en deze te tonen aan de bezoekers van het platform.

Het platform helpt de bezoeker met het vinden van blogs waar die persoon in geïnteresseerd is, door op diverse elementen te kunnen filteren, zoals auteur en categorie.


## Functionele requirements

 - De homepage
 	- Overzicht van alle blogs op volgorde van datum
 	- De blogs zijn verkort en tonen titel, auteur, datum, een kleine intro tekst
 	- Klik je op de blogs, dan ga je door naar de blog detail pagina

 - Blog detail pagina
 	- Bevat titel, auteur, datum en de volledige blog tekst
 	- Relevante artikelen (zoals andere artikelen van dezelfde categorie) worden in verkleind formaat (vergelijkbaar met formaat homepage) onder het artikel getoond.
 	  Plaats ze onder het kopje "Relevant".
 
 - Auteurs
 	- In het menu is altijd een lijst met auteurs te vinden
 	- Als je erop klikt dan kom je op de "bio" pagina van deze auteur
 	- Op de bio pagina vind je informatie als naam, interesses en een biografie van de auteur
 	- Onder de biografie staan alle artikelen van deze auteur onder het kopje "Artikelen van ..." (naam invullen)
 	- Klik je op een auteur van een willekeurige blog (op deze auteur pagina of ergens anders, in klein of groot formaat), dan link je door naar deze bio pagina

 - Categoriën
 	- In het menu is altijd een lijst met categorieën zichtbaar.
 	- Als je op een van de categorieën klikt dan kom je op een categorie pagina.
 	- Op deze pagina worden alle blogs van die categorie getoond in beknopt formaat.
 	- Door te klikken op de blogs kom je op de blog detail pagina
 	- Ook hier 

 - Admin
 	- Het toevoegen, bewerken en verwijderen van blogs gebeurt via een aparte folder op het platform.
 	- Als voorbeeld: Als de reguliere blogs op http://localhost/blog te vinden zijn, dan is het bewerk gedeelte te vinden onder http://localhost/blog/admin
 	- Door bovenstaande constructie hebben we een volledig afgesloten gedeelte voor beheer
 	- Het is aanvankelijk nog niet de bedoeling om een username/wachtwoord functie voor inloggen te hebben
 	- Binnen deze admin omgeving kun je blogs, auteurs en categorieën beheren (Create, Read, Update, Delete)
 	- Bij het maken van blogs items volstaat het om alleen met ENTERs de tekst op te maken. Kleurtjes, afbeeldingen en stijl zijn niet nodig.
	

Mochten bovenstaande functionaliteiten al ruim op tijd gerealiseerd zijn, zie onder een selectie van aanvullende wensen die "nice to have" zijn:

 - Als bezoeker een upvote (like) kunnen geven voor een blog artikel, en de hoeveelheid upvotes tonen
 
 - Als bezoeker commentaar geven op een blog artikel

 - Authenticatie voor blog admins (inloggen met username / password)
 
 - Afbeelding van de auteur tonen, zowel als thumbs bij de beknopte blog items als wat groter bij de detail blogs en de bio.
 
 - Een zoekfunctie om blogs te vinden dmv een zoekbalk en een resultaat pagina van blogs die voldoen aan de zoekopdracht


## Technische requirements

 - Gebruik HTML, CSS en JavaScript voor de schermen
 
 - Gebruik PHP als back-end taal
 
 - Gebruik MySQL als database voor opslag van de blogs en gerelateerde informatie
 
 - Zorg ervoor dat er een logische scheiding is tussen de verschillende verantwoordelijkheden van je applicatie (Model, View, Controller)
 
 - Organiseer je code zoveel mogelijk zodat individuele elementen herbruikbaar zijn. Dubbele / herhalende code moet een belletje doen rinkelen!
 
 - Neem voldoende maatregelen om user input vooraf te valideren voordat je die input gaat verwerken. Koppel een relevante foutmelding terug aan de gebruiker.
 

## Organiseren van werk

 - Bovenstaande functionele requirements zijn erg oppervlakkig. We noemen dit ook wel "Epics". Noteer deze Epics in de vorm van "User Stories" in Trello in de Backlog lijst.
 
 - Maak eerst een "wire-frame" (diagram) van alle schermen, waarbij de schermen in een logische flow aan elkaar geknoopt zijn
 
 - Schets vervolgens wat er aan informatie moet komen op de individuele schermen
 
 - Bepaal vervolgens het eerste minimale product wat er opgeleverd moet worden, bij voorkeur opleverbaar in een paar dagen
 
 - Schrijf alle individuele wensen van dat minimale product uit als "User Stories" in Trello in de To do lijst

 - Maak met GIT een nieuwe feature branch aan vanaf de master (zorg ervoor dat deze eerst up-to-date is)
 
 - Zet de user storie(s) waarmee je aan de gang gaat in "Doing"
 
 - Doe je aanpassingen en test ze. Commit en push je aanpassingen regelmatig, om werk niet kwijt te raken.
 
 - Als je klaar bent met je aanpassingen, doe dan via GitHub een Pull Request en laat bij voorkeur iemand anders jouw branch mergen. Als er teveel tijd overheen gaat ook prima om even zelf te mergen.
 
 - Sleep vervolgens de afgeronde user stories naar de "To review" lijst, zodat de trainer weet welke punten beoordeeld kunnen worden.
 
 - Herhaal bovenstaande stappen net zolang totdat er een opgeleverd product is.

