<?php

require_once __DIR__ . '/../Components/header.php';

?>

<div class="container">
    <div class="row">
        <div class="col-12 col-xs-12 col-md-12 mt-3">
            <div class="box">

                <h1 class="display-4">Choose admin area</h1>
                <h2><a href="index.php?route=admin-blog">Blogs</a></h2>
                <h2><a href="index.php?route=admin-blogger">Bloggers</a></h2>
                <h2><a href="index.php?route=admin-category">Categories</a></h2>

            </div>
        </div>
    </div>
</div>

<?php

require_once __DIR__ . '/../Components/footer.php';

?>
