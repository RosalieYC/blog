<?php

require_once __DIR__ . '/../Components/header.php';

?>

    <div class="container">
        <h1><?= $viewModel['pageTitle']?></h1>
        <p>Fill in the form to add a new blogger</p>

        <form method="post" action="index.php?route=addblogger">

            <div class="row">

                <div class="col-12 col-md-6">
                    <div class="form-group">
                        <label for="title">Name</label>
                        <input type="text" name="name" id="name"  class="form-control" />
                    </div>
                    <div class="form-group">
                        <label for="birth_date">Birth date</label>
                        <input type="date" name="birth_date" id="birth_date"  class="form-control" />
                    </div>
                    <div class="form-group">
                        <label for="address">Address</label>
                        <input type="text" name="address" id="address"  class="form-control" />
                    </div>
                    <div class="form-group">
                        <label for="username">Username</label>
                        <input type="text" name="username" id="username"  class="form-control" />
                    </div>
                    <div class="form-group">
                        <label for="password">Password</label>
                        <input type="text" name="password" id="password"  class="form-control" />
                    </div>
                    <div class="form-group">
                        <label for="image">Image</label>
                        <input type="text" name="image" id="image"  class="form-control" />
                    </div>
                </div>

                <div class="col-12 col-md-6">
                    <div class="form-group">
                        <label for="bio">Bio</label>
                        <textarea name="bio" id="bio" class="form-control" ></textarea>
                    </div>
                </div>
            </div>

            <div class="mt-3">
                <a class="btn btn-outline-secondary" href="./">Back</a>
                <input type="submit" value="Add Blogger" class="btn btn-success float-right">
            </div>

        </form>

    </div>

<?php

require_once __DIR__ . '/../Components/footer.php';

?>