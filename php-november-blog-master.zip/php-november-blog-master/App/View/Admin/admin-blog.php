<?php

require_once __DIR__ . '/../Components/header.php';

?>

<div class="container">
    <h1></h1>
    <?php

    echo '<ul>';
    foreach ($viewModel['blogs'] as $blog) {
        echo '<li>'
             . '<a href="index.php?route=blog&id=' . $blog['id'] . '">'
             . $blog['title'] . '</a> ' . ' written by '
             . $blog['blogger'] . ' '
             . '<form method="post" action="index.php?route=deleteblog&id='.$blog['id'].'" onSubmit="return window.confirm(\'Are you sure you want to delete this blog?\')">
                <a href="index.php?route=editblog&id='.$blog['id'].'">Edit</a>' . ' '
             . '<input type="submit"  value="Delete" class="btn btn-danger "/>'
             . '</form>'
             . '</li>';
    }
    echo '</ul>';
    ?>
    <a class="btn btn-success float-left" href="index.php?route=addblog">New Blog</a>
</div>

<?php

require_once __DIR__ . '/../Components/footer.php';

?>