<?php

require_once __DIR__ . '/../Components/header.php';

?>

    <div class="container">
        <h1><?= $viewModel['pageTitle']?></h1>
        <p>Fill in the form to add a new blog</p>

        <form method="post" action="#">
            <div class="row">
                <div class="col-12 col-md-6">
                    <div class="form-group">
                        <label for="name">Category</label>
                        <input type="text" name="name" id="name"  class="form-control" />
                    </div>
                </div>
            </div>

            <div class="mt-3">
                <a class="btn btn-outline-secondary" href="./">Back</a>
                <input type="submit" value="Add Category" class="btn btn-success float-right">
            </div>

        </form>

    </div>

<?php

require_once __DIR__ . '/../Components/footer.php';

?>