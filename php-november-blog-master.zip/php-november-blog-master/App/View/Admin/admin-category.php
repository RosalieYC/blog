<?php

require_once __DIR__ . '/../Components/header.php';

?>

    <div class="container">
        <h1></h1>
        <?php
        echo '<ul>';
        foreach ($viewModel['categories'] as $category) {
            echo '<li>'
                . '<a href="index.php?route=category&id=' . $category['id'] . '">'
                . $category['name'] . '</a> ' . ' '
                . '<a href="#">Edit</a>' . ' '
                . '<a href="#">Delete</a>'
                . '</li>';
        }
        echo '</ul>';
        ?>
        <a class="btn btn-success float-left" href="index.php?route=addcategory">New Category</a>
    </div>

<?php

require_once __DIR__ . '/../Components/footer.php';

?>