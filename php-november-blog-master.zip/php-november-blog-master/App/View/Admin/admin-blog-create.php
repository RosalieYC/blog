<?php

require_once __DIR__ . '/../Components/header.php';

?>

<div class="container">
    <h1><?= $viewModel['pageTitle']?></h1>
    <p>Fill in the form to add a new blog</p>

    <form method="post" action="#">

        <div class="row">

            <div class="col-12 col-md-6">
                <div class="form-group">
                    <label for="title">Title</label>
                    <input type="text" name="title" id="title"  class="form-control" />
                </div>
                <div class="form-group">
                    <label for="blogger_id">Blogger</label>
                    <select name="blogger_id" id="blogger_id" class="form-control">
                        <?php
                        foreach ($viewModel['bloggers'] as $blogger){
                            echo '<option value="' . $blogger['id'] . '">' . $blogger['name'] . '</option>';
                        }
                        ?>
                    </select>
                </div>
                <div class="form-group">
                    <label for="category_id">Category</label>
                    <select name="category_id" id="category_id" class="form-control">
                        <?php
                        foreach ($viewModel['categories'] as $category){
                            echo '<option value="' . $category['id'] . '">' . $category['name'] . '</option>';
                        }
                        ?>
                    </select>
                </div>
                <div class="form-group">
                    <label for="date">Date</label>
                    <input type="date" name="date" id="date"  class="form-control" />
                </div>
                <div class="form-group">
                    <label for="image">Image</label>
                    <input type="text" name="image" id="image"  class="form-control" />
                </div>
            </div>

            <div class="col-12 col-md-6">
                <div class="form-group">
                    <label for="text">Description</label>
                    <textarea name="text" id="text" class="form-control" ></textarea>
                </div>
            </div>
        </div>

        <div class="mt-3">
            <a class="btn btn-outline-secondary" href="./">Back</a>
            <input type="submit" value="Add Blog" class="btn btn-success float-right">
        </div>

    </form>

</div>

<?php

require_once __DIR__ . '/../Components/footer.php';

?>