<?php

require_once __DIR__ . '/../Components/header.php';

?>

    <div class="container">
        <h1></h1>
        <?php
        echo '<ul>';
        foreach ($viewModel['bloggers'] as $blogger) {
            echo '<li>'
                . '<a href="index.php?route=blogger&id=' . $blogger['id'] . '">'
                . $blogger['name'] . '</a> ' . ' '
                . '<form method="post" action="index.php?route=deleteblogger&id='.$blogger['id'].'" onSubmit="return window.confirm(\'Are you sure you want to delete this blogger?\')"> 
                   <a href="index.php?route=editblogger&id='.$blogger['id'].'">Edit</a>' . ' '
                . '<input type="submit"  value="Delete" class="btn btn-danger "/>'
                . '</form>'
                . '</li>';
        }
        echo '</ul>';
        ?>
        <a class="btn btn-success float-left" href="index.php?route=addblogger">Add Blogger</a>
    </div>


<?php

require_once __DIR__ . '/../Components/footer.php';

?>