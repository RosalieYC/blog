<?php

require_once __DIR__ . '/Components/header.php';

?>

<div class="container">
    <div class="row">
        <div class="col-12 col-xs-12 col-md-12 mt-3">
            <div class="box">

                <h1 class="display-4"><?php echo $viewModel['blog']['title'] ?></h1>

                <p><?php
                    $date = date_create($viewModel['blog']['date']);
                    echo "Written by "  . '<a href="index.php?route=blogger&id=' . $viewModel['blog']['blogger_id'] . '">'
                        . $viewModel['blog']['blogger'] . '</a>' . ", " . date_format($date, 'j F Y') . " in " . $viewModel['blog']['category'] . "." ?>

                <img src="<?php echo $viewModel['blog']['image'] ?>" alt="image" style="max-width: 900px">

                <p class="lead"><?php echo $viewModel['blog']['text'] ?></p>

            </div>
        </div>
    </div>
</div>


<?php

require_once __DIR__ . '/Components/footer.php';

?>
