<?php

require_once __DIR__ . '/Components/header.php';

?>

<div class="container">
    <div class="row">
        <div class="col-12 col-xs-12 col-md-12 mt-3">
            <div class="blog-overview">

    <?php
    foreach ($viewModel['blogs'] as $blog) {
        $date = date_create($blog['date']);
        echo '<div class="box">
            <h3 class="blog-title"><a href="index.php?route=blog&id=' . $blog['id'] . '">' . $blog['title'] . '</a></h3>
        <div class="blog-info"><p>' . "Written by ". '<a href="index.php?route=blogger&id=' . $blog['blogger_id'] . '">' . $blog['blogger'] . '</a>'
            . ", " . date_format($date, 'j F Y') . " in " .
            '<a href="index.php?route=category&id=' . $blog['category_id'] . '">' . $blog['category'] . '</a>' . "." . '</div>
        <div class="blog-image"><img src="' . $blog['image'] . '" alt="relevant picture to blog">'   .   '</div>
        <div class="blog-text">' . substr($blog['text'], 0, 750) . "..." . '</div>
        <a class="btn btn-secondary mt-4" href="index.php?route=blog&id=' . $blog['id'] . '">' . "Read more" . '</a></div>';
    }

    ?>

                </div> <!-- END OF blog-overview -->
            </div> <!-- END OF COL -->
        </div> <!-- END OF ROW -->
</div>  <!-- END OF CONTAINER -->

<?php

require_once __DIR__ . '/Components/footer.php';

?>
