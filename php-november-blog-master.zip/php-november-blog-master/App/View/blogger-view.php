<?php

require_once __DIR__ . '/Components/header.php';

?>
    <div class="container">
        <img class="profile-picture" src="<?php $viewModel['bloggers']['image']?>" alt="picture of blogger">
        <h1><?php $viewModel['bloggers']['name'] ?></h1>
        <p class="subtitle">Information about this blogger</p>

        <?php

        foreach ($viewModel['bloggers'] as $blogger){
            echo '<p>Name: '.$blogger['name'].'</p>';
            echo '<p>Birth date: '.$blogger['birth_date'].'</p>';
            echo '<p>Address: '.$blogger['address'].'</p>';
            echo '<p>Bio: '.$blogger['bio'].'</p>';

        }
        ?>

    </div>  <!-- END OF CONTAINER -->

<?php

require_once __DIR__ . '/Components/footer.php';

?>



