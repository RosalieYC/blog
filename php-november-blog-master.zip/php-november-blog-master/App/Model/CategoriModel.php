<?php

declare(strict_types=1);
namespace App\Model;

class CategoriModel extends BaseModel
{
    public function GetAllCategories()
    {
        $query = "SELECT 
                categories.name,
                categories.id
              FROM 
                categories";

        $statement = $this->getConnection()->prepare($query);
        $statement->execute();

        $categories = $statement->fetchAll();

        return $categories;
    }
    public function getOneCategory($categoryId)

    {
        $query = "SELECT 
                categories.name,
                categories.id
              FROM 
                categories
              WHERE
              id = :categoryId";

        $parameters = [
            'categoryId'=> $categoryId
        ];

        $statement = $this->getConnection()->prepare($query);
        $statement->execute($parameters);

        if($statement->rowCount()>0){
            return $statement->fetch();

        }
        return null;
    }
    public function createCategory(array $category) : int
    {

        $query = "INSERT
                  INTO
                    categories (name)
                  VALUES (
                    :name
                    )
                    ";

        $parameters = [
            'name' => $category['name']
        ];

        $statement = $this->getConnection()->prepare($query);
        $statement->execute($parameters);

        return (int) $this->getConnection()->lastInsertId();

    }
}