<?php

declare(strict_types=1);
namespace App\Model;

class BloggerModel extends BaseModel
{
    public function showAllBloggers(): array
    {
        $query = "SELECT
                    bloggers.address,
                    bloggers.bio,
                    bloggers.birth_date,
                    bloggers.id,
                    bloggers.name,
                    bloggers.password,
                    bloggers.username
                  FROM 
                    bloggers";

        $statement = $this->getConnection()->prepare($query);
        $statement->execute();

        return $statement->fetchAll();
    }
    public function showBlogger(): array
    {
        $query = "SELECT
                    bloggers.address,
                    bloggers.bio,
                    bloggers.birth_date,
                    bloggers.id,
                    bloggers.name,
                    bloggers.password,
                    bloggers.username
                  FROM 
                    bloggers";

        $statement = $this->getConnection()->prepare($query);
        $statement->execute();
        return $statement->fetchAll();
    }
    public function getOneBlogger(int $bloggerId) : ?array // ?array betekent return type of array mag terug
    {
        $query = "SELECT 
                    *
                    FROM 
                      bloggers
                    WHERE 
                      id = :bloggerId";

        $parameters = [
            'bloggerId'=> $bloggerId
        ];

        $statement = $this->getConnection()->prepare($query);
        $statement->execute($parameters);

        if($statement->rowCount()>0){
            return $statement->fetch();

        }
        return null;
    }
    public function createBlogger(array $bloggerFields)
    {

        $query = "INSERT
                  INTO
                    bloggers
                    (
                    name,
                    birth_date,
                    address,
                    bio,
                    username,
                    password,
                    image
                    )
                  VALUES (
                    :name,
                    :birth_date,
                    :address,
                    :bio,
                    :username,
                    :password,
                    :image
                    )
                    ";

        $parameters = [
            'name' => $bloggerFields['name'],
            'birth_date' => $bloggerFields['birth_date'],
            'address' => $bloggerFields['address'],
            'bio' => $bloggerFields['bio'],
            'username' => $bloggerFields['username'],
            'password' => $bloggerFields['password'],
            'image' => $bloggerFields['image']
        ];

        $statement = $this->getConnection()->prepare($query);
        $statement->execute($parameters);

        return (int) $this->getConnection()->lastInsertId();

    }
    public function updateBlogger(int $bloggerId, array $bloggerFields)  : void
    {


        $query = "UPDATE
                    bloggers
                    SET
                        name = :name,
                        birth_date = :birth_date,
                        address = :address,
                        bio = :bio,
                        username = :username,
                        password = :password,
                        image = :image
                    WHERE
                    id = :bloggerId";

        $parameters = [
            'bloggerId' => $bloggerId,
            'name' => $bloggerFields['name'],
            'birth_date' => $bloggerFields['birth_date'],
            'address' => $bloggerFields['address'],
            'bio' => $bloggerFields['bio'],
            'username' => $bloggerFields['username'],
            'password' => $bloggerFields['password']
        ];



        $statement = $this->getConnection()->prepare($query);
        $statement->execute($parameters);

    }
    public function deleteBlogger(int $bloggerId)
    {
        $query ="DELETE FROM 
                  bloggers
                  WHERE
                  id = :bloggerId";

        $parameters = [
            'bloggerId'=>$bloggerId
        ];

        $statement = $this->getConnection()->prepare($query);
        $statement->execute($parameters);
    }
}



