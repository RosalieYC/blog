<?php

declare(strict_types=1);
namespace App\Model;

class BlogModel extends BaseModel
{
    public function getAllBlogs() : array
    {
        $query = "SELECT 
                    blogs.id,
                    blogs.title,
                    blogs.blogger_id,
                    blogs.category_id,
                    blogs.date,
                    blogs.image,
                    blogs.text,
                    bloggers.name AS blogger,
                    categories.name AS category
                    FROM 
                      blogs
                      LEFT JOIN bloggers ON (bloggers.id = blogs.blogger_id)
                      LEFT JOIN categories ON (categories.id = blogs.category_id)
                    ORDER BY blogs.date DESC";

        $statement = $this->getConnection()->prepare($query);
        $statement->execute();

        $blogs = $statement->fetchAll();

        return $blogs;
    }


//    public function summarize($blogs, $limit_lines){
//        $count = 0;
//        foreach(explode("\n", $blogs) as $line){
//            $count++;
//            echo $line."\n";
//            if ($count == $limit_lines) break;
//        }
//    }
  
    public function getOneBlog($blogId) : array
    {
        $query = "SELECT 
                    blogs.id,
                    blogs.title,
                    blogs.blogger_id,
                    blogs.category_id,
                    blogs.date,
                    blogs.image,
                    blogs.text,
                    bloggers.name AS blogger,
                    categories.name AS category
                    FROM 
                      blogs
                      LEFT JOIN bloggers ON (bloggers.id = blogs.blogger_id)
                      LEFT JOIN categories ON (categories.id = blogs.category_id)
                   WHERE
                    blogs.id = :blogId";


        $parameters = [
            'blogId' => $blogId
        ];

        $statement = $this->getConnection()->prepare($query);
        $statement->execute($parameters);


        if ($statement->rowCount() > 0) {
            $blog = $statement->fetch();
            return $blog;
        } else {
            return null;
        }
    }

    public function createBlog(array $blog) : int
    {

        $query = "INSERT
                  INTO
                    blogs
                    (
                    title,
                    blogger_id,
                    category_id,
                    date,
                    image,
                    text
                    )
                  VALUES (
                    :title,
                    :blogger_id,
                    :category_id,
                    :date,
                    :image,
                    :text
                    )
                    ";

        $parameters = [
            'title' => $blog['title'],
            'blogger_id' => $blog['blogger_id'],
            'category_id' => $blog['category_id'],
            'date' => $blog['date'],
            'image' => $blog['image'],
            'text' => $blog['text']
        ];

        $statement = $this->getConnection()->prepare($query);
        $statement->execute($parameters);

        return (int) $this->getConnection()->lastInsertId();

    }

    public function updateBlog(int $blogId, array $blogFields)  : void
    {


        $query = "UPDATE
                    blogs
                    SET
                        title = :title,
                        blogger_id = :blogger_id,
                        category_id = :category_id,
                        date = :date,
                        image = :image,
                        text = :text
                    WHERE
                    id = :blogId";

        $parameters = [
            'blogId' => $blogId,
            'title' => $blogFields['title'],
            'blogger_id' => $blogFields['blogger_id'],
            'category_id' => $blogFields['category_id'],
            'date' => $blogFields['date'],
            'image' => $blogFields['image'],
            'text' => $blogFields['text']
        ];



        $statement = $this->getConnection()->prepare($query);
        $statement->execute($parameters);



    }
    public function deleteBlog(int $blogId)
    {
        $query ="DELETE FROM 
                  blogs
                  WHERE
                  id = :blogId";

        $parameters = [
            'blogId'=>$blogId
        ];

        $statement = $this->getConnection()->prepare($query);
        $statement->execute($parameters);
    }
}
