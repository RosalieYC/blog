<?php

declare(strict_types=1);
namespace App\Controller;

class BaseController
{
    public function renderView(string $view, array $viewModel)
    {

        if(!isset($viewModel['pageTitle'])){
            $viewModel['pageTitle'] = '';
        }
        require_once (__DIR__.'/../View/'.$view.'.php');

    }
}