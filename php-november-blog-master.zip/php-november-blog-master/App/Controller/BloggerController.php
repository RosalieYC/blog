<?php

declare(strict_types=1);

namespace App\Controller;

use App\Model\BloggerModel;
use App\Model\BlogModel;

class BloggerController extends BaseController
{
    public function showBlogger()
    {
        $bloggerModel = new BloggerModel();
        $bloggers = $bloggerModel->showBlogger();

        $blogModel = new BlogModel();
        $blogs = $blogModel->getAllBlogs();

        $viewModel = [
            'pageTitle' => 'Blogger',
            'bloggers' => $bloggers,
            'blogs' => $blogs
        ];

        $this->renderView('blogger-view', $viewModel);
    }
    public function newBlogger()
    {

        $viewModel = [
            'pageTitle' => 'Add a new Blogger'
        ];

        $this->renderView('Admin/admin-blogger-create',$viewModel);
    }
    public function addBlogger(array $bloggerFields)
    {
        $bloggerModel = new bloggerModel();
        $bloggerModel->createBlogger($bloggerFields);

        header('Location: index.php?route=admin-blogger');
    }
    public function showEditBlogger(int $bloggerId)
    {
        $bloggerModel = new BloggerModel();
        $blogger = $bloggerModel->getOneBlogger($bloggerId);

        $viewModel = [
            'pageTitle' => 'Edit Blogger',
            'blogger' => $blogger,
        ];

        $this->renderView('Admin/admin-blogger-edit',$viewModel);
    }
    public function updateBlogger ($bloggerId, $bloggerFields)
    {
        $bloggerModel = new BloggerModel();
        $bloggerModel->updateBlogger($bloggerId, $bloggerFields);

        header('Location: index.php?route=admin-blogger');

    }
    public function deleteBlogger ($bloggerId)
    {
        $bloggerModel = new bloggerModel();
        $bloggerModel->deleteBlogger($bloggerId);

        header('Location: index.php?route=admin-blogger');

    }
}
