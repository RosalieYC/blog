<?php

declare(strict_types=1);
namespace App\Controller;


use App\Model\BloggerModel;
use App\Model\BlogModel;
use App\Model\CategoriModel;

class BlogController extends BaseController
{
    public function showBlogs()
    {
        $blogModel = new BlogModel();
        $blogs = $blogModel->getAllBlogs();

        $viewModel = [
            'pageTitle' => 'Blogs',
            'blogs' => $blogs
        ];

        $this->renderView('blog-overview', $viewModel);
    }

    public function showBlog(int $blogId)
    {
        $blogModel = new BlogModel();
        $blog = $blogModel->getOneBlog($blogId);

        if ($blog) {
            $viewModel = [
                'pageTitle' => $blog['title'],
                'blog' => $blog,
                'blogId' => 'id'
            ];
        }

        $this->renderView('blog-detail', $viewModel);
    }

    public function showCategories () {
        $categoriModel = new CategoriModel();
        $categories = $categoriModel->GetAllCategories();

    }

    public function newBlog()
    {
        $bloggerModel = new BloggerModel();
        $bloggers = $bloggerModel->showAllBloggers();

        $categoryModel = new CategoriModel();
        $categories = $categoryModel->GetAllCategories();

        $viewModel = [
            'pageTitle' => 'Add a new Blog',
            'bloggers' => $bloggers,
            'categories' => $categories
        ];

        $this->renderView('Admin/admin-blog-create',$viewModel);
    }
    public function addBlog(array $bookFields)
    {
        $blogModel = new blogModel();
        $newBlogId = $blogModel->createBlog($bookFields);

        $blog = $blogModel->getOneBlog($newBlogId);
        print_r($blog);

        header('Location: index.php?route=blog&id=' . $newBlogId);
    }
    public function showEditBlog(int $blogId)
    {
        $blogModel = new BlogModel();
        $blog = $blogModel->getOneBlog($blogId);

        $bloggerModel = new BloggerModel();
        $bloggers = $bloggerModel->showAllBloggers();

        $categoryModel = new CategoriModel();
        $categories = $categoryModel->GetAllCategories();

        $viewModel = [
            'pageTitle' => 'Edit Blog',
            'blog' => $blog,
            'bloggers' => $bloggers,
            'categories' => $categories

        ];
        $this->renderView('Admin/admin-blog-edit',$viewModel);
    }
    public function updateBlog ($blogId, $blogFields)
    {
        $blogModel = new BlogModel();
        $blogModel->updateBlog($blogId, $blogFields);

        header('Location: index.php?route=blog&id='.$blogId);

    }
    public function deleteBlog ($blogId)
    {
        $blogModel = new blogModel();
        $blogModel->deleteBlog($blogId);

        header('Location: index.php?route=admin-blog');

    }
}