<?php

declare(strict_types=1);
namespace App\Controller;

use App\Model\CategoriModel;

class CategoryController extends BaseController
{
    public function showCategory()
    {
        $categoryModel = new CategoriModel();
        $categories = $categoryModel->GetAllCategories();

        $viewModel = [
            'pageTitle' => 'Categories',
            'categories' => $categories
        ];

        $this->renderView('category-overview', $viewModel);
    }
    public function newCategory()
    {
        $viewModel = [
            'pageTitle' => 'Add a new Category',
        ];

        $this->renderView('Admin/admin-category-create',$viewModel);
    }
    public function addCategory(array $categoryFields)
    {
        $categoryModel = new CategoriModel();
        $newCategoryId = $categoryModel->createCategory($categoryFields);

        $category = $categoryModel->getOneCategory($newCategoryId);
        print_r($category);

        header('Location: index.php?route=admin-category');
    }
}