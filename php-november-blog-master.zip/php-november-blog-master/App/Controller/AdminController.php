<?php

declare(strict_types=1);
namespace App\Controller;


use App\Model\BlogModel;
use App\Model\BloggerModel;
use App\Model\CategoriModel;

class AdminController extends BaseController
{
    public function adminOverview ()
    {
        $viewModel = [
            'pageTitle' => 'Admin',
        ];

        $this->renderView('Admin/admin-overview', $viewModel);
    }
    public function adminBlogs ()
    {
        $blogModel = new BlogModel();
        $blogs = $blogModel->getAllBlogs();

        $viewModel = [
            'pageTitle' => 'Admin-Blogs',
            'blogs' => $blogs
        ];

        $this->renderView('Admin/admin-blog', $viewModel);
    }
    public function adminBloggers ()
    {
        $bloggerModel = new BloggerModel();
        $bloggers = $bloggerModel->showAllBloggers();

        $viewModel = [
            'pageTitle' => 'Admin-Bloggers',
            'bloggers' => $bloggers
        ];

        $this->renderView('Admin/admin-blogger', $viewModel);
    }
    public function adminCategories ()
    {
        $categoryModel = new CategoriModel();
        $categories = $categoryModel->GetAllCategories();

        $viewModel = [
            'pageTitle' => 'Admin-Catagories',
            'categories' => $categories
        ];

        $this->renderView('Admin/admin-category', $viewModel);
    }
}